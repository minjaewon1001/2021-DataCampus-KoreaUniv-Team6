#!/usr/bin/env python
# coding: utf-8

# In[ ]:


#가중치변수 config 변수 설정 자기 디렉토리에 맞게끔 해줘야 합니다.
#utility.py 가 같은 폴더에 있으면 좋음. (utils.py 를 이름을 바꿔보았음.)
#face_crop(video_capture("C://python_files/new/sample.mp4", 10)); <= 사용법은 이렇게 하면 됨.


# In[30]:


import cv2
from matplotlib import pyplot as plt
import os
import time


# In[31]:


import sys
sys.path.append("C://python_files/new")

from utility import *


# In[32]:


def video_capture(videoFile, second_set):
    #videoFile = "C://python_files/new/sample.mp4" # 동영상 파일 주소 
    capture = cv2.VideoCapture() 
    capture.open(videoFile)

    # 초당 프레임 수를 get 클래스로 계산해 변수에 담음
    fps = capture.get(cv2.CAP_PROP_FPS) 
    # 영상의 총 프레임 수를 get 클래스로 계산해 변수에 담음
    frame_count = capture.get(cv2.CAP_PROP_FRAME_COUNT)

    timestamps = [capture.get(cv2.CAP_PROP_POS_MSEC)]
    calc_timestamps = [0.0]

    duration = frame_count / fps 
    print("영상의 길이 : ", duration, "초")

    #second_set = 3 #여기서 몇 초인지를 지정해주자.
    count = 0 # count 번째 사진 increase_width = 10 # 여기서 몇초마다 찍을건지 세팅하면 됌.

    second_width = 0.25 #앞 뒤 몇 초 frame을 들고 올 것인지 지정
    if second_set <= second_width :
        second = 0
    elif second_set >= duration - second_width :
        second = duration - second_width
    else :
        second = second_set - second_width

    print(second_set, "초 앞 뒤 ",second_width,"초 frame 불러오기")

    frame_list = []
    while True:
        if second > second_set + second_width :
            break
        capture.set(cv2.CAP_PROP_POS_MSEC, second * 1000) 
        ret,frame = capture.read()
        frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        #print(second, "초 에서 캡쳐") 

        second = second + 1/fps

        
        
        frame_list.append(frame_rgb)
    return frame_list

    print('----- Finish Video Capture! -----')


# In[33]:


CONF_THRESHOLD = 0.5
NMS_THRESHOLD = 0.4
IMG_WIDTH = 416
IMG_HEIGHT = 416

# Give the configuration and weight files for the model and load the network
# using them.
CUR_DIR = os.path.abspath('.')
weights_path = os.path.join(CUR_DIR, 'C://python_files/pafy/yoloface/model-weights/yolov3-wider_16000.weights')
config_path =  os.path.join(CUR_DIR, 'C://python_files/pafy/yoloface/cfg/yolov3-face.cfg')
net = cv2.dnn.readNetFromDarknet(config_path, weights_path)
net.setPreferableBackend(cv2.dnn.DNN_BACKEND_OPENCV)
net.setPreferableTarget(cv2.dnn.DNN_TARGET_CPU)


def face_detection(frame):
    # Create a 4D blob from a frame.
    try:
        crop_list=[]
        blob = cv2.dnn.blobFromImage(frame, 1 / 255, (IMG_WIDTH, IMG_HEIGHT),
                                        [0, 0, 0], 1, crop=False)
        # Sets the input to the network
        net.setInput(blob)
        # Runs the forward pass to get output of the output layers
        outs = net.forward(get_outputs_names(net))

        # Remove the bounding boxes with low confidence
        faces = post_process(frame, outs, CONF_THRESHOLD, NMS_THRESHOLD)
        #print(faces)
        print('[i] ==> # detected faces: {}'.format(len(faces)))
        print('#' * 60)
        
        for i in range(len(faces)):
            crop = frame[faces[i][1]:faces[i][1]+faces[i][3],faces[i][0]:faces[i][0]+faces[i][2]]
            crop_list.append(crop)
    except :
        print('[i] ==> # detected faces: 0')
    return crop_list


# In[34]:


def face_crop(frame_list):
    frame_list_crop = []
    for i in frame_list:
        frame_list_crop.append(face_detection(i))
    return frame_list_crop


# In[39]:


#face_crop(video_capture("C://python_files/new/sample.mp4", 10));


# In[ ]:


# img_list = face_crop(video_capture("C://python_files/new/sample.mp4", 10));


# In[37]:


#len(img_list)


# In[25]:


#len(img_list[0])


# In[42]:


#for i in face_crop(video_capture("C://python_files/new/sample.mp4", 10)):
    #for j in i:
        #plt.imshow(j)
        #plt.show()
        


# In[ ]:


#jupyter nbconvert --to script test.ipynb

